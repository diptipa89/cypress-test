# Prerequisite
Installing libraries
```bash
npm install
```
or
```bash
yarn
```

\
&nbsp;

# Run cypress tests

```bash
npm run cypress:run

```
or
```bash
yarn cypress:run

```

\
&nbsp;

# Open cypress

```bash
npm run cypress:run

```
or
```bash
yarn cypress:run

```